Matthew Puentes Andrew Levy
This program reads through a list of text files provided by the user, compiles the words into a binary tree, and then prints them into an output file with the
amount of times that word appears in the files.

This program is run by using the command ./PA3 outputFile inputfile1 inputfile2 inputfile3...

The most major difficulty while creating the program was the reading of strings from the file, and covering all of the edge cases with punctuation and hyphens.

We used some code from the powerpoint shown in class in out tree.c and tree.h files